Author: Carson Stevens

Comments:
  Apparently I suck at trivia. Maybe you'll do better on the questions than I did haha.

Extra Credit:
  * Added customizable quiz interface to DB trivia API with jQuery promises.
    * Dynamic content into structured template
  * Using my custom jQuery functions to make text Neon.
  * Customizable quiz length
  * Question are multiple choice or boolean (included weights for difficulties)
  * Added local storage for top score
