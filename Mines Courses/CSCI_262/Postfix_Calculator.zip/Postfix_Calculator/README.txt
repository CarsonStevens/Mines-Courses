Author: Carson Stevens

Challenges:
    The biggest challenge was taking the the string input and converting it to a double.
    I know the stod() function was mentioned, but it was even easier to take in the 
    previous stringstream and convert it to another that read in doubles and then
    store the double value. Otherwise, there wasn't any real challenges
    
Likes:
    It was fun to implement the different types of functions that weren't just the regular
    binary functions.
    
Dislikes:
    I don't really see this being useful for anything other than teaching the funtionality
    of the stack.
    
Time Spent:
    2.5 hours
    
Features added:
    "^", "sqrt", "ln", "sin", "tan", "cos", "log" (reads the base first and then what is being taken in)
    
    log example
    
        3 2 log     this would read log base 3 of 2
        
    "nthRoot": This takes the nth Root of a number
        Reads the root first and then the radicand
        
    nthRoot example
        
        3 2 nthRooth    this would read the 3rd root of 2.