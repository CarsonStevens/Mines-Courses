Author: Carson Stevens

Challenges:
    The largest challenges were storing the word families. I knew that a map was 
    a good choice and that I was going to store a vector of strings for the value,
    but I was having a hard time finding a good way to store the word family index
    positions of the chosen letter. Eventually, I settled on using 1s and 0s to
    indicate whether the letter was there or not and stored them as strings because
    they are super easy to compare. I also hated using the coded template as it 
    had a ton of bugs and didn't work exactly how I wanted. It took a ton of time
    to understand what was going on and how it was working. If I had to do it again,
    I would write my own starter code.
    
Likes:
    I thought that this was a fun application of what we have been learning and
    it has been fun to trick my friends into thinking they are really bad at hangman.
    
Dislikes:
    Not much except for my own fault of not writing my own starter code/interface.
    
Time:
    6 hours
    
