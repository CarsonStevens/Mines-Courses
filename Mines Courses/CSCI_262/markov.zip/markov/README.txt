Author: Carson Stevens
Collaborators: N/A

Challenges: The biggest challenge how figuring out how this worked. Even with
    the prompt and example explaining it, it still was a little unclear. But with
    further research, I understood the prompt better and after I understood what
    was supposed to happening, it was much easier to code. 
    
    
Likes: This assignment is so cool how it works to predict text. It was fun to show
    my friends. They were super impressed. I had lots of fun with loading in other
    text to see what it would predict.
    
Dislikes: I don't have a ton that I hated about this project besides the intial
    learning curve to understand what is happening.
    
Time Spent:
    8 hours