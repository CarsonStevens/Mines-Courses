#ifndef USEFUL_H
#define USEFUL_H

void eat_line();
bool inquire(const char query[]);

#endif