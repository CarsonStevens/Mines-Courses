/*
 * Authors: Ryan West, Carson Stevens
 * Exercise: Level Game
 */
package levelPieces;

import gameEngine.Drawable;
import gameEngine.InteractionResult;
import gameEngine.Moveable;

/**
 * This piece is designed to kill the player if within 1 space of the player.
 * Can only be beaten by landing on the piece.
 */
public class Knight extends GamePiece implements Moveable{

	public Knight() {
		super('K', 14);
	}

	public  InteractionResult interact(Drawable [] pieces, int playerLocation){
		
		//iterate through the board until it finds a piece
		for (int i = 0; i < pieces.length; i++){
			if(pieces[i] == null){
				continue;
			}
			
			Drawable temp = pieces[i];
			
			//does the interaction if the piece found is this class
			if(temp instanceof Knight){
				if ((i == playerLocation - 1) || (i == playerLocation +1)) {
					return InteractionResult.KILL;
				}
			}
		}
		return InteractionResult.NONE;
	}

	public void move(Drawable[] gameBoard, int playerLocation) {
		if (gameBoard[this.getLocation() - 1] == null){	// checks spot is free		
			int tempLoc = this.getLocation();
			this.setLocation(getLocation() - 1);
			gameBoard[this.getLocation()] = this;
			gameBoard[tempLoc] = null;
		}		
	}
	
}
