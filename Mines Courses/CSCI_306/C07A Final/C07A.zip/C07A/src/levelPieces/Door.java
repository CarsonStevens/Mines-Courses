/*
 * Authors: Ryan West, Carson Stevens
 * Exercise: Level Game
 */
package levelPieces;
import gameEngine.Drawable;
import gameEngine.InteractionResult;
/**
* This piece is meant to advance the player to the next level when the player lands on it
*/
public class Door extends GamePiece{

	public Door() {
		super('D', 1);
	}

	public InteractionResult interact(Drawable [] pieces, int playerLocation) {
		for (int i = 0; i < pieces.length; i++){
			if(pieces[i] == null){
				continue;
			}
			Drawable temp = pieces[i];
			
			//does the interaction if the piece found is this class
			if(temp instanceof Door){
				if (i == playerLocation) {
					return InteractionResult.ADVANCE;
				}
			}
		}
		return InteractionResult.NONE;
	}
}
