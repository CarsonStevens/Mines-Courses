/*
 * Authors: Ryan West, Carson Stevens
 * Exercise: Level Game
 */
package levelPieces;

import gameEngine.Drawable;

/**
 * This piece only implements drawable, it has no interactive functions and is only meant to confuse the player with its presence.
 */
public class Illusion implements Drawable{

	int location = 18;
	char symbol = 'I';
	public int getLocation() {
		return location;
	}

	public void setLocation(int location) {
		this.location = location;
	}


	public Illusion() {
	}

	@Override
	public void draw() {
		System.out.print(symbol);
	}

}
