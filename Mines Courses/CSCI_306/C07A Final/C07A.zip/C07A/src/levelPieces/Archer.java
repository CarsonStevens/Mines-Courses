/*
 * Authors: Ryan West, Carson Stevens
 * Exercise: Level Game
 */
package levelPieces;

import gameEngine.Drawable;
import gameEngine.InteractionResult;
import gameEngine.Moveable;

/**
 * This Piece will attack the player if the player is exactly 2 spaces away
 * It moves only to right and will guard the treasure win it reaches it.
 */
public class Archer extends GamePiece implements Moveable{

	public Archer() {
		super('A' , 15);
	}

	public InteractionResult interact(Drawable [] pieces, int playerLocation) {
		
		for (int i = 0; i < pieces.length; i++){
			if(pieces[i] == null){
				continue;
			}
			Drawable temp = pieces[i];
			
			//does the interaction if the piece found is this class
			if(temp instanceof Archer){
				if ((i == playerLocation + 2) || (i == playerLocation-2)) {
					return InteractionResult.HIT;
				}
			}
		}
		return InteractionResult.NONE;
		

	}

	public void move(Drawable[] gameBoard, int playerLocation) {

		if(this.getLocation() + 1 == gameBoard.length){
			return;
		}
		if (gameBoard[this.getLocation() +1] == null){ //checks if space is free
			
			int tempLoc = this.getLocation();
			this.setLocation(getLocation() + 1);
			gameBoard[this.getLocation()] = this;
			gameBoard[tempLoc] = null;
		}	
	}
}