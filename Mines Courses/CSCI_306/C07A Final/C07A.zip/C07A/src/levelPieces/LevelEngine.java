/*
 * Authors: Ryan West, Carson Stevens
 * Exercise: Level Game
 */
package levelPieces;
import java.util.ArrayList;
import java.util.Arrays;

import gameEngine.Drawable;
import gameEngine.GameEngine;
import gameEngine.Moveable;

public class LevelEngine {

	Drawable [] board = new Drawable[GameEngine.BOARD_SIZE];				//Gameboard
	ArrayList<GamePiece> interactingPieces = new ArrayList<GamePiece>();	//list of pieces that can interact
	ArrayList<Moveable> moveable = new ArrayList<Moveable>();				//list of pieces that can move


	public int level;
	public LevelEngine() {
		moveable.add(new Archer());
		moveable.add(new Grunt());
		moveable.add(new Knight());
		
		interactingPieces.add(new Archer());
		interactingPieces.add(new Grunt());
		interactingPieces.add(new Knight());
		interactingPieces.add(new Door());
		interactingPieces.add(new Treasure());

	}
	
	//make all indexes in the board null and populate the board with all pieces
	//moves pieces over depending on the level
	public void createLevel(int lvl) {
		Arrays.fill(board, null);
		for(int i=0 ; i < interactingPieces.size(); i++){
			GamePiece temp = interactingPieces.get(i);
			board[temp.getLocation() + lvl] = interactingPieces.get(i);
		}
		
		Illusion temp1 = new Illusion();
		board[temp1.getLocation()] =temp1;
	}

	//return board
	public Drawable[] getBoard() {
		return this.board;
	}
	
	//Should return an Arraylist containing only pieces that move
	public ArrayList<Moveable> getMovingPieces() {
		return this.moveable;
	}
	
	//should return an Arraylist containing only pieces that interact
	public ArrayList<GamePiece> getInteractingPieces(){
		return this.interactingPieces;
	}
	
	//players starting location on every level
	public int getPlayerStartLoc(){
		return 10;
	}
}
