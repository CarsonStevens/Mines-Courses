/*
 * Authors: Ryan West, Carson Stevens
 * Exercise: Level Game
 */
package levelPieces;

import gameEngine.Drawable;
import gameEngine.InteractionResult;
/**
 * This piece gives the player a point if the player lands on it.
 */
public class Treasure extends GamePiece{

	public Treasure() {
		super('T' , 18);
	}

	public InteractionResult interact(Drawable[] pieces, int playerLocation) {
		for (int i = 0; i < pieces.length; i++){
			if(pieces[i] == null){
				continue;
			}
			Drawable temp = pieces[i];
			
			//does the interaction if the piece found is this class
			if(temp instanceof Treasure){
				if (i == playerLocation) {
					return InteractionResult.GET_POINT;
				}
			}
		}
		return InteractionResult.NONE;
	}

}
