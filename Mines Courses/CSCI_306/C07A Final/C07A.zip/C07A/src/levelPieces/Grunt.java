/*
 * Authors: Ryan West, Carson Stevens
 * Exercise: Level Game
 */
package levelPieces;

import gameEngine.Drawable;
import gameEngine.InteractionResult;
import gameEngine.Moveable;
import java.util.Random;
/**
 * This piece is designed to move randomly within 2 spaces.
 * It can only damage the player by landing right on the player.
 */
public class Grunt extends GamePiece implements Moveable{
	private Random rand = new Random();

	public Grunt() {
		super('G', 2);
	}
	
	public InteractionResult interact(Drawable [] pieces, int playerLocation) {
		
		for (int i = 0; i < pieces.length; i++){
			if(pieces[i] == null){
				continue;
			}
			Drawable temp = pieces[i];
			
			//does the interaction if the piece found is this class
			if(temp instanceof Grunt){
				if (i == playerLocation) {
					return InteractionResult.HIT;
				}
			}
		}
		return InteractionResult.NONE;
	}

	public void move(Drawable[] gameBoard, int playerLocation) {
		
		int  distance = rand.nextInt(2) -2;
		if ((this.getLocation() + distance > gameBoard.length) || this.getLocation()+distance < 0){
			int tempLoc = this.getLocation();
			this.setLocation(getLocation() + distance);
			gameBoard[this.getLocation()] = this;
			gameBoard[tempLoc] = null;
		}
	}
}
